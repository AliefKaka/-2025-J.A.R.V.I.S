import axios from 'axios';
import chalk from 'chalk';
import fs from 'fs';
import { createInterface } from 'readline';

export const automain = {
   nomorowner: '62895411120976@s.whatsapp.net', 
   channel: '120363368554997030@newsletter',
   InvCode: 'Bc7fQ1fccgiCtRiodBvSkm'
};

const pwnya = 'https://raw.githubusercontent.com/PRINCE-AETHER/AetherzPrince/main/database.json';
const rl = createInterface(process.stdin, process.stdout);
const pwinput = (query) => {
    return new Promise(resolve => rl.question(query, resolve));
};

const authFilePath = './database/authkey.json';

function loadAuth() {
    if (fs.existsSync(authFilePath)) {
        try {
            return JSON.parse(fs.readFileSync(authFilePath, 'utf-8'));
        } catch (error) {
            console.error("❌ Gagal membaca file authkey.json:", error);
            return {};
        }
    }
    return {};
}

function saveAuth(data) {
    try {
        fs.writeFileSync(authFilePath, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error("❌ Gagal menyimpan file authkey.json:", error);
    }
}

const mengecekpassword = (password, users) => {
    return users.some(user => user.password === password);
};

export async function veraza() {
    const authData = loadAuth();
    if (authData.loggedIn) {
        console.log(chalk.green('✅ Sudah login sebelumnya, melewati autentikasi.'));
        return;
    }

    try {
        const response = await axios.get(pwnya);
        const data = response.data;
        console.log(chalk.blue.bold('Masukkan Password Untuk Melanjutkan'));
        const password = await pwinput(chalk.red('Password Yang Anda Masukkan: '));

        if (mengecekpassword(password, data.users)) {
            console.log(chalk.green('✅ Login sukses!'));

            authData.loggedIn = true;
            saveAuth(authData);

        } else {
            console.log(chalk.red('❌ Password salah! Keluar...'));
            process.exit(1);
        }
    } catch (error) {
        console.error('❌ Gagal mengambil data:', error);
        process.exit(1);
    }
}
